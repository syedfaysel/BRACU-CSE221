

# Task 01 : Shortest Path Algorithm Dijkstra
# Design the graph class



class Graph:
    def __init__(self, nodes, edge_weights):
        self.nodes = nodes
        self.graph = self.build_graph(nodes, edge_weights)
        
    def build_graph(self, nodes, edge_weights):

        graph = {}
        for node in nodes:
            graph[node] = {}
        
        graph.update(edge_weights)
        
        for node, edges in graph.items():
            for adj_node, edge_weight in edges.items():
                if graph[adj_node].get(node, False) == False:
                    graph[adj_node][node] = edge_weight
                    
        return graph
    
    def get_nodes(self):
        
        return self.nodes
    
    def get_adj_nodes(self, node):
        
        connections = []
        for out_node in self.nodes:
            if self.graph[node].get(out_node, False) != False:
                connections.append(out_node)
        return connections
    
    def get_edge_weight(self, node1, node2):
        
        return self.graph[node1][node2]




# Dijkstra Algorithm

def dijkstra_algorithm(graph, source_node):
    unvisited_nodes = list(graph.get_nodes())
  
    shortest_path = {}
    previous_nodes = {}
  
    infinity = 1e8
    for node in unvisited_nodes:
        shortest_path[node] = infinity
    
    shortest_path[source_node] = 0
    
   
    while unvisited_nodes:
        
        current_min_node = None
        for node in unvisited_nodes: 
            if current_min_node == None:
                current_min_node = node
            elif shortest_path[node] < shortest_path[current_min_node]:
                current_min_node = node
                
        
        pasher_nodes = graph.get_adj_nodes(current_min_node)
        for node in pasher_nodes:
            expected_weight = shortest_path[current_min_node] + graph.get_edge_weight(current_min_node, node)
            if expected_weight < shortest_path[node]:
                shortest_path[node] = expected_weight
                
                previous_nodes[node] = current_min_node
 
        
        unvisited_nodes.remove(current_min_node)
    
    return previous_nodes, shortest_path


# Driver Code


file_in = open("input1.txt", "r")
file_out = open("output1.txt", "w")

nodes = []

lines = file_in.read().splitlines()
for line in lines:
    node1, node2, edge_weight = line.split()
    if node1 not in nodes:
        nodes.append(node1)
    if node2 not in nodes:
        nodes.append(node2)

edge_weights = {}
for node in nodes:
    edge_weights[node] = {}

# print(nodes)

for line in lines:
    node1, node2, edge_weight = line.split()
    edge_weights[node1][node2] = int(edge_weight)

graph = Graph(nodes, edge_weights)
previous_nodes, shortest_path = dijkstra_algorithm(graph= graph, source_node="Motijheel")



# Print Shortest Path

def print_path(previous_nodes,shortest_path, source_node, dest_node):
    path = []
    node = dest_node
    
    while node != source_node:
        path.append(node)
        node = previous_nodes[node]
 
    path.append(source_node)
    
    # print(shortest_path[dest_node])
    # print(" -> ".join(reversed(path)))
    file_out.write(f"{shortest_path[dest_node]}\n")
    file_out.write(f"{'->'.join(reversed(path))}")

print_path(previous_nodes, shortest_path, source_node="Motijheel", dest_node="MOGHBAZAR")

