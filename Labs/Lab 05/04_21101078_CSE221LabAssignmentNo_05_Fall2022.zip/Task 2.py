from queue import PriorityQueue

file_in = open("input2.txt", "r")
file_out = open("output2.txt", "w")


def dijkstra(Graph, source):
    p_q = PriorityQueue()
    visited = [0]*len(Graph)
    INF = 1e9+10
    dist = [INF]*len(Graph)
    dist[source] = 0
    p_q.put((dist[source], source))
    while (p_q.empty() == False):
        u = p_q.get()[1]
        if visited[u] == 1:
            continue
        visited[u] = 1
        for v in Graph[u]:
            newMin = dist[u] + v[1]
            if newMin < dist[v[0]]:
                dist[v[0]] = newMin
                p_q.put((dist[v[0]], v[0]))

    return (dist[len(Graph)-1])
    # return dist
    # file_out.write(f"{dist[len(Graph)-1]}\n")


tc = int(file_in.readline())

for i in range(tc):
    N, M = map(int,file_in.readline().split())

    adj_list = [[] for _ in range(N+1)]

    for j in range(M):
        u, v, wt = map(int, file_in.readline().split())
        adj_list[u].append((v, wt))

    dist = dijkstra(adj_list, 1)
    file_out.write(f"{dist}\n")
