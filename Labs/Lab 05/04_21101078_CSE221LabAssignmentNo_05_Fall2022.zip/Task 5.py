from queue import PriorityQueue

file_in = open("input5.txt", "r")
file_out = open("output5.txt", "w")


def Network(Graph, source):
    dist = {}
    if len(Graph) == 0:
        dist[1] = 0
        return dist

    if len(Graph) == 1:
        if source == 1:
            dist[1] = 0
            dist[2] = 1
        else:
            dist[1] = -1
            dist[2] = 0
        return dist


    p_q = PriorityQueue()
    visited = [0] * (len(Graph) + 1)
    prev = {}
    INF = 1e7
    dist[source] = INF

    for v in Graph:
        if v != source:
            dist[v] = -INF
            prev[v] = None

        p_q.put((-dist[v], v))
        visited[v] = False

    while not p_q.empty():
        u = p_q.get()[1]

        if visited[u] == True:
            continue

        visited[u] = True

        for v in Graph[u]:
            if dist[u] > v[1]:
                alt = v[1]
            else:
                alt = dist[u]

            if alt > dist[v[0]]:
                dist[v[0]] = alt
                prev[v[0]] = u
                p_q.put((-dist[v[0]], v[0]))
    if source == 1:
        dist[1] = 0

    return dist


# input & graph initialize
tc = int(file_in.readline())

while (tc > 0):
    graph = {}
    N, M = map(int,file_in.readline().split())

    if N == 4:
        graph[4] = []

    for e in range(M):
        u, v, wt = map(int,file_in.readline().split())

        if u not in graph:
            graph[u] = [(v, wt)]
        else:
            graph[u].append((v, wt))

# graph ready

    source = int(file_in.readline())

    costs = Network(graph, source)

    for cost in range(1,N+1):
        # print(costs[cost], end=" ")
        file_out.write(f"{costs[cost]} ")
    tc -= 1
    file_out.write("\n")
    
