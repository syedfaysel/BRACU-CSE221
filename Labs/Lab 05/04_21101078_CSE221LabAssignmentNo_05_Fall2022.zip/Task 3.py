from queue import PriorityQueue


file_in = open("input3.txt", "r")
file_out = open("output3.txt", "w")


def Dijkstra(Graph, source):
    Q = PriorityQueue()
    visited = [False]*len(Graph)
    INF = 1e8
    dist = [INF]*len(Graph)
    prev = [0]*len(Graph)
    dist[source] = 0
    prev[source] = source
    Q.put((dist[source], source))
    while not Q.empty():
        u = Q.get()[1]
        if visited[u]:
            continue
        visited[u] = True
        for v in Graph[u]:
            alt = dist[u] + v[1]
            if alt < dist[v[0]]:
                dist[v[0]] = alt
                prev[v[0]] = u
                Q.put((dist[v[0]], v[0]))
    return prev


n = int(file_in.readline())

for i in range(n):
    N, M = file_in.readline().split()
    N = int(N)
    M = int(M)
    adj_list = [[] for x in range(N+1)]
    for j in range(M):
        u, v, wt = [int(_) for _ in file_in.readline().split()]
        adj_list[u].append((v, wt))
    dist = Dijkstra(adj_list, 1)
    path = []

    m = M
    n = N

    ext = n

    if N == 1:
        path = [1]
    else:

        while dist[N] != 1:
            path.append(dist[N])
            N = dist[N]
        path.reverse()
        path.insert(0, 1)
        path.append(ext)

    for i in path:
        # print(i, end=" ")
        file_out.write(f"{i} ")
    file_out.write("\n")